# One-Page Portfolio Website

## Project Overview
This project is a **one-page portfolio website** built using semantic HTML. It includes sections for About, Projects, Skills, and Contact, as well as internal navigation and accessibility features.

## Folder Structure
```
labassignment1/
│
├── index.html
├── images/
│   └── profile.jpg
└── README.md
```

## Features
- Semantic HTML tags (`<header>`, `<nav>`, `<main>`, `<section>`, `<footer>`)
- Hero introduction section
- About section with profile image (with `alt` text)
- Projects listed with `<ul>` and `<article>` elements
- Skills table displaying proficiency levels
- Functional contact form with required fields
- “Skip to main content” accessibility link
- Clean indentation and lowercase filenames

## How to Run
1. Clone or download the repository.
2. Open `index.html` in any modern web browser.
3. Test navigation links and form fields.

## Author
**Shubham Chaprana**  
Web Development Assignment – 2025
